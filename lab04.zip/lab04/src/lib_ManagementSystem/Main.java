package lib_ManagementSystem;
import java.util.ArrayList;
public class Main {

	public static void main(String[] args) {
		
		Book book1 = new Book("Test Book", "Raiden Lor", true);
		Book book2 = new Book("Harry Potter", "Raiden Lor", true);
		Book book3 = new Book("Test Book 2nd Edition", "Andrew Yang", false);
		Book book4 = new Book("Wishing Start", "Phil", true);
		
		Member Raiden = new Member("Raiden Lor");
		Member Andrew = new Member("Andrew Yang");
		
		System.out.println();
		
		Library library = new Library();
		library.addBook(book1);
		library.addBook(book2);
		library.addBook(book3);
		library.addBook(book4);
		System.out.println();

		library.displayBooks();
		System.out.println();
		
		Raiden.borrowBook(library, "Test Book 2nd Edition");
		Raiden.displayBooks();
		Raiden.returnBook(library, "Test Book 2nd Edition");
		library.searchBook("Test Book 2nd Edition");
		System.out.println();
		Andrew.returnBook(library, "Harry Potter");
		Andrew.borrowBook(library, "Wishing Star");
		Andrew.displayBooks();
		library.searchBook("Test Book 2nd Editions");
		
	}

}
